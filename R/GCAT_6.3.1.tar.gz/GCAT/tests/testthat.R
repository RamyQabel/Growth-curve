library(testthat)
library(GCAT)

test_check("GCAT")
